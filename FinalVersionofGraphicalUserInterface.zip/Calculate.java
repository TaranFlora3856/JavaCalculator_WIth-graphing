//imported libraries
import java.util.Stack;
import java.util.*;

public class Calculate{ 
    /*
        This is a calss that hold all the funtions to put out string into Revese polish notation
    */
          
         public static ArrayList<String> toeknize(String equation){
             /*
             This function tokenises the sting and puts it into an arraylist with each operation and number
             */
            ArrayList<String> listEquation = new ArrayList();
            char[] charArray = equation.toCharArray();
            String num = "";
            System.out.println("______________________________");
            for(int i = 0; i < charArray.length; i++){
               
                
                if(charArray[i] == '.' || RPNR.isNum(String.valueOf(charArray[i])) == 1){
                    num += charArray[i];
                }else if(charArray[i] == '—'){
                    num += '-';
                }else{
                        listEquation.add(num);
                        num = "";
                        listEquation.add(String.valueOf(charArray[i]));
                    }
                    
                }
                System.out.println(listEquation);
                System.out.println("<-------------------------->");
                return listEquation;
            }
           
          public static boolean hasBalancedBrackets(String code) {
                ArrayList<Character> codeList = new ArrayList(); 
                char[] codeChars = code.toCharArray();
                
                for(char c: codeChars){
                    if(c == '(' || c == ')'){
                        codeList.add(c);
                    }
                } 
                if(Collections.frequency(codeList,')') == Collections.frequency(codeList,'(') ){
                    return true;
                }else{
                    return false;
                }

            }
            
        //Ques and stack for the Shunting Yard algorithm    
        public static Stack<String> opStack = new Stack(); 
        public static Queue<String> numQueue = new LinkedList();
        
                public static Queue<String> FillemUP(ArrayList<String> equation){
            
            try{
                for(int j = 0; j <= equation.size()-1; j++){
                     if(equation.get(j).equals("√")){
                        float numSqrt = Float.parseFloat(equation.get(j+1));
                        equation.remove(j);
                        equation.remove(j);
                        equation.add(j,Double.toString(Math.sqrt(numSqrt)));
                    }
                }
            }catch(Exception e){}
            
            for(String c: equation){
                //System.out.print("opStack:");
                //System.out.println(opStack);
                //System.out.print("numQueue:");
                //System.out.println(numQueue);
                switch (c){
                    case "+":
                    case "-":
                    case "x":
                    case "/":
                    case "^":
                    case "(":
                    case "√":
                    case "s":
                    case "c":
                    case "t":
                        System.out.print(c);System.out.println("<-- c");
                        try{
                            if(BEDMAScheck(c,opStack.peek()) == 1){ //1 is true
                                opStack.push(c);
                                System.out.print(c);System.out.println("<-- c1-try");

                            }else if (BEDMAScheck(c,opStack.peek()) == 2){ //2 is false
                                //little odd but we shall see
                                System.out.print(c);System.out.println("<-- c2-try");
                                while(opStack.size() > 0){
                                   String holder = opStack.peek();
                                   System.out.print("h:");System.out.println(holder);
                                   System.out.print("c:");System.out.println(c);
                                   opStack.pop();
                                   if(holder.equals("(") == false){
                                        numQueue.add(holder);
                                        //System.out.print("opStack67:");
                                        //System.out.println(opStack);
                                        //System.out.print("numQueue:");
                                        //System.out.println(numQueue);
                                        //break;//weird asf
                                    }
                                    if(holder.equals("(")){ ////////////////////////////////////////////////////////////
                                        opStack.add(c);
                                        break;
                                    }
                                  if(BEDMAScheck(c,opStack.peek()) == 1){
                                      opStack.push(c);
                                      break;
                                   }
                                }
                            }else{
                                System.out.print(c);System.out.println("else triggered on nedmas opstack");
                            }
                        }catch (Exception e){
                            try{
                                //System.out.println("CATCH EXCETIPON");
                                if(BEDMAScheck(c,"-") == 1){ //1 is true
                                    //System.out.println("12345");
                                    opStack.push(c);
                                }else if (BEDMAScheck(c,"-") == 2){ //2 is false
                                    System.out.println("6,7");
                                    //little odd but we shall see
                                    for(int i = 0; i < opStack.size()-1; i++){
                                      String holder = opStack.peek();
                                      opStack.pop();
                                      if(holder.equals("(") == false){
                                            numQueue.add(holder);
                                            System.out.print("opStack:");
                                            System.out.println(opStack);
                                            System.out.print("numQueue:");
                                            System.out.println(numQueue);
                                        }
                                      //numQueue.add(holder);
                                      System.out.println("-----------");
                                      if(BEDMAScheck(c,opStack.peek()) == 1){
                                        opStack.push(c);
                                        break;
                                      }
                                    }
                                }else{
                                    System.out.print(c);System.out.println("else triggered on bedmas opstack catch");
                            
                                }
                                }catch (Exception w){
                                    Main.equation = "ERROR";
                            }
                            
                        }
                        break;
                    case ")":
                        try{
                        BEDMAScheck(c,opStack.peek());
                        }catch(Exception e){}
                        break;
                    
                    default:
                       //System.out.println("h:");
                        //System.out.println(c);
                        if(c.equals(".") || c.equals("√") || c.equals("s")){
                            //System.out.println("llgjhfhgjhgfdhsdfbvaergbdytfng");
                            numQueue.add(c);
                            break;
                        }else{
                            try{
                                if(Float.parseFloat(c) > -1000000 || c.equals("(")){
                                    numQueue.add(c);
                                }
                                break;
                            }catch(Exception e){
                                System.out.println(".");
                            }
                            break;
                        }
                }
                if(numQueue.size() < opStack.size()){
                    Main.equation = "ERROR";
                }
                
            }
            System.out.print("opStack:");
            System.out.println(opStack);
            System.out.print("numQueue:");
            System.out.println(numQueue);
            while(opStack.size() > 0){
                numQueue.add(opStack.peek());
                opStack.pop();
            }
            System.out.println("Post-fix:");
            System.out.println(numQueue);
            return numQueue;
        }
    public static int BEDMAScheck(String op, String preOp){
        //Brackets,Expontnets,/x,+-
        ArrayList<String> BEDMAS = new ArrayList(List.of("X","(","s","t","c","√","^","/","x","-","+",")"));
        if(BEDMAS.indexOf(op) <= BEDMAS.indexOf(preOp)){
            return 1;
        }else if(op.equals("+") && BEDMAS.indexOf(preOp) == BEDMAS.indexOf("-")){
            return 1;
        }else if(op.equals("x") && BEDMAS.indexOf(preOp) == BEDMAS.indexOf("/")){
            return 1;
        }else if(op.equals(")")){
            System.out.println("{-----------------------------}");
            for(int i = 0; i <= opStack.size()-1; i++){
                System.out.println("{-----------------------------}");
                System.out.println(opStack);
                try{
                    if(opStack.peek().equals("(") == false){
                        numQueue.add(opStack.peek());
                    }
                    opStack.pop();
                    if(opStack.peek().equals("(")){
                        opStack.pop();
                        break;
                    }
                }catch (Exception e){
                    System.out.println("eee");
                }
            }
            return 3;
        }else if(op.equals(")")) {
            while (!opStack.isEmpty() && !opStack.peek().equals("(")) {
                numQueue.add(opStack.pop());
            }
            // pop the "(" itself
            if (!opStack.isEmpty() && opStack.peek().equals("(")) {
                opStack.pop();
            }
            return 3; // means we handled a closing bracket
        }else{
            return 2;
        }
    }
}