//imported libraries
import javax.swing.*; // This is for the components
import java.awt.*; // This is for the fonts and colours
import java.awt.event.*; // This is for the action listeners
import static java.awt.event.KeyEvent.*; // This is for the key listeners
import java.util.*;

public class NumberButtons extends Button{
    private String me;
    private int interationx;
    private int interationy;
    private int buttonWidth = 60;
    private int type;
    public NumberButtons(String me, int interationx, int interationy, int type){
        this.me = me;
        this.interationx = interationx;
        this.interationy = interationy;
        this.type = type;

    }
    public String reutrnFunction(){
        return this.me;
    }
    public void buttonDisplay(JFrame frame){
        System.out.println("printed to da screen");
        //JFrame frame = new JFrame("Calculator");
        JButton button1 = new JButton(me);
        int longer = 0;
        if(this.me == "Equals"){
            longer = 260;
        }
        button1.setBounds(interationx*(buttonWidth+5)+5, 70*interationy+50, buttonWidth+longer, buttonWidth);
        frame.add(button1);
        button1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               if(NumberButtons.this.me.equals("Equals")){
                   NumberButtons.this.me = "=";
               }else if(NumberButtons.this.me.equals("Sin")){
                   NumberButtons.this.me = "s(";
               }else if(NumberButtons.this.me.equals("Cos")){
                   NumberButtons.this.me = "c(";
               }else if(NumberButtons.this.me.equals("Tan")){
                   NumberButtons.this.me = "t(";
               }
               
               System.out.println(NumberButtons.this.me);
               Main.addCharacter(NumberButtons.this.me);
               
            }
        });
    }
    
   
}