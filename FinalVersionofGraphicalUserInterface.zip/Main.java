/**
 * @author Taran
 */
//imported libraries
import javax.swing.*; // This is for the components
import java.awt.*; // This is for the fonts and colours
import java.awt.event.*; // This is for the action listeners
import static java.awt.event.KeyEvent.*; // This is for the key listeners
import java.util.*;

public class Main {
	
    /**
     * Describe your app here.
     *
     * @param args the command line arguments
     * @return void
     */
    public static JLabel answerBox = new JLabel("Equation: ");
    public static int length = 1200;
    public static int width = 475;
    public static String equation = "";
    public static JFrame frame = new JFrame("Calculator");
    
    public static void main(String[] args) {
        
        // Start your app here
        // Initializes the frame
        frame.setSize(length,width);
        System.out.println("Started");
        //Answer box
        answerBox.setBounds(0, 0, 450, 100);
        answerBox.setFont(new Font(answerBox.getFont().getName(), Font.PLAIN, 25));
        answerBox.setOpaque(true);
        answerBox.setBackground(new Color (255,255,255)); // Using a predefined color
        frame.add(answerBox);
        
        String[] buttonNamse = {"1","2","3","0","x","/","4","5","6","+","-","√","7","8","9","^","(",")","X",".","Sin","Cos","Tan","CLR","—","Equals",""," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "};
        int j = 0;
    
        NumberButtons[] buttons = new NumberButtons[30];
        //new numberButtons("X",0,400); 
        for (int r = 1; r <= 5; r++){
            for(int i = 0; i < ((length-600)/100); i+=1){
                System.out.println(i);
                if(r==5 && i == 2){
                    break;
                }
                if(i > width-60-20){i+=1000;break;}
                if(buttonNamse[i] == "="){
                    buttons[i] = new NumberButtons(buttonNamse[j],i,r,20); 
                }
                buttons[i] = new NumberButtons(buttonNamse[j],i,r,1); 
                buttons[i].buttonDisplay(frame);
                j++;
            }
        }
        
        frame.setLayout(null);
        frame.setVisible(true);
    }
    
    public static void addCharacter(String toAdd){
        equation = equation + toAdd;
        if(toAdd.equals("CLR")){
            equation = "";
            calculate.opStack.clear();
            calculate.numQueue.clear();
            RPNR.calcStack.clear();
        }
        String eq1 = "";
        if(toAdd.equals("=")){///////////////////EQUALS SECTIOn
            eq1 = equation;
            System.out.println("Answering");
            if(calculate.hasBalancedBrackets(equation)){
                System.out.println("Balanced brackets.");
            //try{
                Graphics g = frame.getGraphics();
                Graph gr1=new Graph();
                gr1.setEquation(equation);
                gr1.setVisible(true);
                equation = RPNR.calcRPN(Calculate.FillemUP(Calculate.toeknize(equation)));
                
                //}catch (Exception e){
                 // equation = "Error";
                //}
                    
                }else{
                    equation = "Error";
                }
                if(equation.equals(eq1) && !equation.equals("Error")){
                    equation = "Error";
                }else if(equation.equals("Infinity")){
                    equation = "Error";
                }else if(equation.equals("NaN")){
                    equation = "Error";
                }
        }
        /*
        if(equation.equals(eq1)){
            equation = "Error";
        }
        */
        answerBox.setText(equation);
     }
    
}