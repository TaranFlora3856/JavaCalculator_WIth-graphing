//imported libraries
import javax.swing.*; // This is for the components
import java.awt.*; // This is for the fonts and colours
import java.awt.event.*; // This is for the action listeners
import static java.awt.event.KeyEvent.*; // This is for the key listeners
import java.util.*;

public abstract class Button extends JButton{ //abstrac class for the Jbuttons
    public abstract String reutrnFunction(); //all butons but be able to return somthine
}