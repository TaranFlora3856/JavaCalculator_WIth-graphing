//imported libraries
import java.util.Stack;
import java.util.*;

public class RPNR{
    public static Stack<String> calcStack = new Stack(); 
    
    public static String calcRPN(Queue<String> RPN){
        while(RPN.size() > 0){
            if(isNum(RPN.peek())== 1 ){
                calcStack.add(RPN.peek());
                RPN.remove();
            }else if(isNum(RPN.peek()) == 2){
                String operation = RPN.peek();
                RPN.remove();
                //try{////////////////////////////////////break all sin(x)+x very very bad try catech
                String num1 = calcStack.peek();
                calcStack.pop();
                try{//////////////////////////////////////////////////////////////////////////////ugly try
                String num2 = calcStack.peek();
                calcStack.pop();
                calcStack.add(eval(num1,operation,num2));
                System.out.println(calcStack);
                System.out.println(RPN);
                }catch(Exception e){}
               // }catch(Exception p){}
            }else if(isNum(RPN.peek()) == 3){
                String operation = RPN.peek();
                RPN.remove();
                String num1 = calcStack.peek();
                calcStack.pop();
                calcStack.add(evalSingles(num1,operation));
                System.out.println(calcStack);
                System.out.println(RPN);
            }
        }
        try{
            return calcStack.peek();
        }catch (Exception w){
            return "0";
        }
    }
    
    public static String evalSingles(String num1, String operation){
        switch(operation){
            case "√":
                return Float.toString((float)Math.sqrt(Float.parseFloat(num1)));
            case "s":
                return Float.toString((float)Math.sin(Double.parseDouble(num1)*(double)Math.PI/180));
            case "c":
                double anglecos = Math.toRadians(Double.parseDouble(num1));
                double cosValue = Math.round(Math.cos(anglecos)*1000.0)/1000.0;      
                if (Math.abs(cosValue) > 1e3) {
                            cosValue = 0;
                        }
                    return String.format("%3f",cosValue);
                //return Float.toString((float)Math.cos(Double.parseDouble(num1)*(double)Math.PI/180));
            case "t":
                double angle = Math.toRadians(Double.parseDouble(num1));
                double tanValue = Math.round(Math.tan(angle)*1000.0)/1000.0;      
                if (Math.abs(tanValue) > 1e3) {
                            tanValue = 0;
                        }
                    return String.format("%6f",tanValue);
            default:
                return "ERror";
        }        
    }



    public static int isNum(String character){
        switch(character){
            case "+":
            case "-":
            case "x":
            case "/":
            case "^":
            case "(":
                return 2;
            case"√":
            case "s":
            case "c":
            case "t":
                return 3;
            default:
                try{
                    Float.parseFloat(character);
                        return 1;
                }catch(Exception e){
                    if(character.equals(".")){
                        return 1;
                    }
                    return 0;
                }
                
        }
    }
    
    public static String eval(String num1, String operation, String num2){
         switch(operation){
             //Float.parseFloat(floatString);
            case "+":
                return Float.toString(Float.parseFloat(num2)+Float.parseFloat(num1));
            case "-":
                return Float.toString(Float.parseFloat(num2)-Float.parseFloat(num1));
            case "x":
                return Float.toString(Float.parseFloat(num2)*Float.parseFloat(num1));
            case "/":
                return Float.toString(Float.parseFloat(num2)/Float.parseFloat(num1));
            case "^":
                return Float.toString((float)Math.pow((int)Math.floor(Float.parseFloat(num2)),(int)Math.floor(Float.parseFloat(num1))));
            default:
                return "error";
         }        
    }
    
}