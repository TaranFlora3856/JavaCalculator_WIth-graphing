//imported libraries
import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;
import java.util.*;

public class Graph extends JFrame {

    public static String equation = "";

    public Graph() {
        setSize(600, 450);
        setLocation(400, 0); 
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        add(new GraphPanel()); // add drawing panel
    }
    
    public void setEquation(String equation){
        this.equation = equation;
    }

    class GraphPanel extends JPanel {

        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            drawAxis(g);
        }

        private void drawAxis(Graphics g) {
            Graphics2D g2 = (Graphics2D) g;
            g2.setColor(Color.BLACK);
            g2.setStroke(new BasicStroke(2));
            
            //ArrayList<String> listEquation = calculate.toeknize(equation);
            ArrayList<String> listEquation2 = Calculate.toeknize(equation);
            ArrayList <Integer> xp = new ArrayList();
            ArrayList <Integer> yp = new ArrayList();
            int indexSwap = 0; //errror with theindex swap part!!!!!!!!!!!! that why no working
            for(int q = -500; q <= 500; q+=1){
                ArrayList<String> listEquation = new ArrayList<>();
//                ArrayList<String> listEquation = calculate.toeknize(equation);
                Calculate.opStack.clear();
                Calculate.numQueue.clear();
                RPNR.calcStack.clear(); 
                
                //for(int l = 0; l <= Collections.frequency(listEquation2, "X"); l++){
                   if(listEquation2.contains("X")){
                       
                            for (String token : listEquation2) {
                                if (token.equals("X")) {
                                    listEquation.add(Integer.toString(q));
                                } else {
                                    listEquation.add(token);
                                }
                            }
                       
                       
                       
                       
                       //System.out.println("GOOD to GRAPH");
                       /*
                         listEquation.add(0,Integer.toString(q));
                         System.out.println(listEquation);
                         indexSwap = listEquation2.indexOf("X");
                         Collections.swap(listEquation, indexSwap, 0);
                         listEquation.remove(0);
                         System.out.println("{_________________________________________________________}");
                            System.out.println(listEquation);
                            */
                       // }
                            /*
                        else if(!equation.contains("X") && q == 0){
                           System.out.println("ERRRROR"); 
                           break;
                        }
                        */
                }
                //listEquation.add(0,Integer.toString(q/2));
                //Collections.swap(listEquation, indexSwap, 0);
                //listEquation.remove(0);
                System.out.print("PPP:");System.out.println(listEquation);
                String yVal = RPNR.calcRPN(Calculate.FillemUP(listEquation));
                if(yVal == "NaN"){
                    continue;
                }
                int yValInt = (int)(Float.parseFloat(yVal))/10;
                System.out.println("k:");System.out.println(yValInt);
                System.out.println(q);
                g2.setColor(Color.RED);
                if(yValInt > 10000 || yValInt <-10000){
                    continue;
                }
                g2.fillOval((int)q+300,((getHeight() / 2)-yValInt),2,2);
                xp.add((int)q+300);
                yp.add(((getHeight() / 2)-yValInt));
               
            }
            g2.setColor(Color.BLACK);
            g2.drawLine(getWidth() / 2, 0, getWidth() / 2, getHeight());   // vertical line
            g2.drawLine(0, getHeight() / 2, getWidth(), getHeight() / 2);            
            g2.setColor(Color.RED);

            for(int h = 0; h < xp.size()-1; h++){
                 try{
                    g2.drawLine(xp.get(h), yp.get(h), xp.get(h+1), yp.get(h+1));            
                 }catch(Exception e){}   
            }

           // Line2D lin = new Line2D.Float(100, 100, 250, 260);
           // g2.draw(lin);
        }
    }
}